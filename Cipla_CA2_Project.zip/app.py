import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

st.set_page_config(page_title="Cipla Financial Dashboard", layout="wide")

# ---------- Load data ----------
df = pd.read_csv("company_financials_clean.csv")

# Recompute derived columns in case the clean CSV doesn't already have them
if "Profit_Trend" not in df.columns:
    df["Profit_Trend"] = np.where(
        df["Net_Profit"] > df["Net_Profit"].shift(1),
        "Profit Grew", "Profit Declined"
    )
    df.loc[0, "Profit_Trend"] = "Profit Grew"

if "Sales_Growth" not in df.columns:
    df["Sales_Growth"] = df["Sales"].pct_change() * 100
if "Net_Profit_Growth" not in df.columns:
    df["Net_Profit_Growth"] = df["Net_Profit"].pct_change() * 100

# ---------- Title ----------
st.title("Financial Dashboard: Cipla")
st.caption("Data source: Screener.in | Built for CA2 — Company Financial Performance Dashboard")

# ---------- KPI cards ----------
c1, c2, c3 = st.columns(3)
c1.metric("Latest Sales (Cr)", f"{df['Sales'].iloc[-1]:,.0f}")
c2.metric("Latest Net Profit (Cr)", f"{df['Net_Profit'].iloc[-1]:,.0f}")
c3.metric("Latest OPM %", f"{df['OPM_Percent'].iloc[-1]:.1f}%")

st.divider()

# ---------- Chart 1: Sales & Net Profit trend ----------
st.subheader("Sales & Net Profit Trend")
fig1, ax1 = plt.subplots(figsize=(9, 4))
ax1.plot(df["Period"], df["Sales"], marker="o", label="Sales")
ax1.plot(df["Period"], df["Net_Profit"], marker="o", label="Net Profit")
ax1.set_xticklabels(df["Period"], rotation=45, ha="right")
ax1.legend()
st.pyplot(fig1)

# ---------- Chart 2: OPM % bar chart ----------
st.subheader("Operating Profit Margin (%)")
fig2, ax2 = plt.subplots(figsize=(9, 4))
ax2.bar(df["Period"], df["OPM_Percent"], color="teal")
ax2.set_xticklabels(df["Period"], rotation=45, ha="right")
st.pyplot(fig2)

# ---------- Chart 3: Box plot ----------
st.subheader("Net Profit Distribution by Profit Trend")
fig3, ax3 = plt.subplots(figsize=(6, 4))
df.boxplot(column="Net_Profit", by="Profit_Trend", ax=ax3)
plt.suptitle("")
ax3.set_ylabel("Net Profit (Cr)")
st.pyplot(fig3)

st.divider()

# ---------- Model comparison ----------
st.subheader("Model Comparison: Logistic Regression vs Decision Tree")

model_df = df.dropna(subset=["Sales_Growth", "OPM_Percent", "Interest", "Other_Income", "Profit_Trend"])
X = model_df[["Sales_Growth", "OPM_Percent", "Interest", "Other_Income"]]
y = model_df["Profit_Trend"]

if len(model_df) >= 6 and y.nunique() > 1:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    log_model = LogisticRegression(max_iter=1000)
    log_model.fit(X_train, y_train)
    log_acc = accuracy_score(y_test, log_model.predict(X_test))

    tree_model = DecisionTreeClassifier(random_state=42)
    tree_model.fit(X_train, y_train)
    tree_acc = accuracy_score(y_test, tree_model.predict(X_test))

    results = pd.DataFrame({
        "Model": ["Logistic Regression", "Decision Tree"],
        "Accuracy": [f"{log_acc:.2f}", f"{tree_acc:.2f}"]
    })
    st.table(results)
    st.caption("Note: sample size is small (few quarters of data), so accuracy figures are indicative only.")
else:
    st.info("Not enough data variety to train models yet — add more periods to company_financials_clean.csv.")

st.divider()
st.caption("Company Financial Performance Dashboard — CA2 Project")
