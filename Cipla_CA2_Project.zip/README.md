# Cipla — CA2 Financial Dashboard Project

**⚠️ IMPORTANT — READ FIRST**
`company_financials.csv` in this zip contains **placeholder sample numbers**, not real Cipla figures.
I don't have live access to Screener.in, so before you submit you MUST:

1. Go to https://www.screener.in, search **Cipla**.
2. Open **Quarterly Results** and **Profit & Loss**, get 12+ periods.
3. Export/copy the real numbers into the same column layout used in `company_financials.csv`
   (Period, Sales, Operating_Profit, OPM_Percent, Other_Income, Interest, Depreciation,
   Profit_Before_Tax, Net_Profit, EPS).
4. Replace the placeholder file with your real data, then re-run the notebook so
   `company_financials_clean.csv` regenerates with real numbers.
5. Copy the regenerated clean CSV next to `app.py` before deploying to Hugging Face.

Submitting with placeholder numbers would fail the "real financial data" requirement of the
assignment — so treat this zip as a ready-to-run scaffold, not a finished submission.

## What's in this zip

| File | Purpose |
|---|---|
| `company_financials.csv` | Sample-structure CSV — **replace with real Cipla data** |
| `Cipla_CA2_Dashboard.ipynb` | Colab notebook: cleaning, stats, 3 charts, model comparison (Steps 8–12) |
| `app.py` | Streamlit dashboard: KPIs, 3 charts, model table (Step 13) |
| `company_financials_clean.csv` | Placeholder "clean" CSV so `app.py` runs out of the box |
| `requirements.txt` | Dependencies for Hugging Face Spaces |

## How to run

### 1. Notebook (Google Colab)
- Upload `Cipla_CA2_Dashboard.ipynb` to Colab.
- Run the upload cell and select your **real** `company_financials.csv`.
- Run all cells top to bottom. This produces `company_financials_clean.csv` and 3 chart images.

### 2. Local test of the dashboard (optional but recommended)
```bash
pip install -r requirements.txt
streamlit run app.py
```
Confirm it opens in your browser at `localhost:8501` before deploying.

### 3. Deploy to Hugging Face Spaces
1. Create a free account at https://huggingface.co
2. Click **New Space** → choose the **Streamlit** SDK.
3. On the Space's Files page, **Add File → Upload Files** and add:
   - `app.py`
   - `requirements.txt`
   - `company_financials_clean.csv` (your real, cleaned data)
4. Wait for the build to say **Running** — your dashboard is live at:
   `huggingface.co/spaces/<your-username>/<space-name>`
5. Open the link in a private/incognito window to confirm a visitor with no account can see it.

## Submission checklist
- [ ] Real Cipla data from Screener.in (not the placeholder numbers)
- [ ] Notebook run end-to-end with real data, charts + model comparison visible
- [ ] `company_financials.csv` and `company_financials_clean.csv` (real data)
- [ ] Hugging Face Space live and tested in a private browser window
- [ ] Written summary with findings + all links (GitHub, HF Space)
- [ ] Submitted via the CA form by **27th July, 5 PM**
